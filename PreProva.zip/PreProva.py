lista = []

#função para repetir a operação
def funcao():
    for i in range(5):
        while True:
            try:
                valores = float (input(f"insira a {i+1}ª velocidade do motor: "))
                lista.append(valores)
                break
                
            except ValueError:
                print("\nValor invalido. Apenas numeros.\n")
         
def valores_lista():
    print("\nLISTA:",lista)
    return lista

def media_valores():
    media = sum(lista) / len(lista)
    print("\nMÉDIA:", media)
    return media

def MaiorValor():
    maior = max(lista)
    print("\nMAIOR VALOR:", maior)
    return maior

def menorvalor():
    menor = min(lista)
    print("\nMENOR VALOR:", menor)
    return menor

def somavalores():
    soma = sum(lista)
    print("\nSOMA DOS VALORES:", soma)
    return soma

funcao()

valores_lista()
media_valores()
MaiorValor()
menorvalor()
somavalores()
#realização da função primeiro para q o usuario possa realizar outra depois (se quiser)


#while para receber a informação da decisao do usuario
while True:
    resposta = str(input("\nVocê deseja fazer uma nova coleta?\n(s/n): ")).lower()
        
    if(resposta == 's'):
        lista.clear()
        funcao()
        valores_lista()
        media_valores()
        MaiorValor()
        menorvalor()
        somavalores()
        
    elif resposta == 'n':
        print("Programa encerrado.")
        break
    else:
        print("Valor invalido. (s) para sim, (n) para não")
     
     